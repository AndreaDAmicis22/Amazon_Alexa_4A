let alexa = require("alexa-app");
let app = new alexa.app("Skill");

app.launch((request, response) => {
  response.say("Ciao").send();
})

app.intent("massa", {
    slots:{"cibo":"AMAZON.Food"},
    utterances: ["quante calorie ha {uno|lo|il|la} {-|cibo}"]
},(request, response) => {
    let cibo = request.slot("cibo");
    response.say("Fai schifo mangi " + cibo);
});

exports.handler = app.lambda();

if (process.argv[2] === 'schema') {
  console.log(app.schemas.skillBuilder());
  console.log(app.utterances());
}
